<?php 

/* Previent Direct Access */
if ( ! defined( 'ABSPATH' ) ) exit;

?>
    </div>
  </div>
  <!-- Libs JS -->
  <!-- Tabler Core -->
  <script src="<?php echo SITE_URL ?>/dist/js/tabler.min.js"></script>
  <script src="<?php echo SITE_URL ?>/dist/js/demo.min.js"></script>
</body>
</html>